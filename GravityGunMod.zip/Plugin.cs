using BepInEx;
using UnityEngine;

namespace GravityGunMod
{
    [BepInPlugin("com.melty.gravitygun", "Half-Life Zero-Point Gravity Gun", "1.0.0")]
    public class GravityGunPlugin : BaseUnityPlugin
    {
        private float range = 15.0f;
        private float throwForce = 35.0f;
        private Rigidbody heldObject = null;
        private Transform holdPoint;

        void Awake()
        {
            Logger.LogInfo("Half-Life Zero-Point Gravity Gun Plugin initialized successfully!");
        }

        void Update()
        {
            // Right-click: Grab / Pull object
            if (Input.GetMouseButtonDown(1))
            {
                TryGrabObject();
            }
            else if (Input.GetMouseButton(1) && heldObject != null)
            {
                HoldObject();
            }
            else if (Input.GetMouseButtonUp(1))
            {
                ReleaseObject();
            }

            // Left-click: Launch held object
            if (Input.GetMouseButtonDown(0) && heldObject != null)
            {
                LaunchObject();
            }
        }

        private void TryGrabObject()
        {
            Ray ray = Camera.main.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
            if (Physics.Raycast(ray, out RaycastHit hit, range))
            {
                Rigidbody rb = hit.collider.GetComponent<Rigidbody>();
                if (rb != null)
                {
                    heldObject = rb;
                    heldObject.useGravity = false;
                    heldObject.drag = 10;
                }
            }
        }

        private void HoldObject()
        {
            if (holdPoint == null)
            {
                GameObject go = new GameObject("HoldPoint");
                go.transform.parent = Camera.main.transform;
                go.transform.localPosition = new Vector3(0, 0, 2.5f);
                holdPoint = go.transform;
            }

            Vector3 moveDirection = (holdPoint.position - heldObject.transform.position);
            heldObject.velocity = moveDirection * 10f;
        }

        private void ReleaseObject()
        {
            if (heldObject != null)
            {
                heldObject.useGravity = true;
                heldObject.drag = 1;
                heldObject = null;
            }
        }

        private void LaunchObject()
        {
            if (heldObject != null)
            {
                heldObject.useGravity = true;
                heldObject.drag = 1;
                heldObject.AddForce(Camera.main.transform.forward * throwForce, ForceMode.Impulse);
                heldObject = null;
            }
        }
    }
}
