# Half-Life Zero-Point Gravity Gun for R.E.P.O.

Brings Gordon Freeman's iconic Zero-Point Energy Field Manipulator into R.E.P.O.!

## Features
- **Right Click (Hold)**: Distance grab and pull heavy loot, barrels, and objects towards you.
- **Left Click**: Launch grabbed objects forward with immense force to clear obstacles or crush threats.
- Fully compatible with BepInEx 5 in co-op extraction sessions.
